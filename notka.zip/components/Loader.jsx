function Loader() {
    return (
        <div className="Loader">            
            <div className="loading">
                <div className="guns">
                    <div className="gilza"></div>
                    <div className="gilza"></div>
                </div>
                <div className="guns c1">
                    <div className="gilza"></div>
                    <div className="gilza"></div>
                </div>
                <div className="guns c2">
                    <div className="gilza"></div>
                    <div className="gilza"></div>
                </div>
                <div className="guns c3">
                    <div className="gilza"></div>
                    <div className="gilza"></div>
                </div>
                <div className="guns c4">
                    <div className="gilza"></div>
                    <div className="gilza"></div>
                </div>
                <div className="guns c5">
                    <div className="gilza"></div>
                    <div className="gilza"></div>
                </div>
                <div className="guns c6">
                    <div className="gilza"></div>
                    <div className="gilza"></div>
                </div>
                <div className="guns c7">
                    <div className="gilza"></div>
                    <div className="gilza"></div>
                </div>
            </div>
        </div>
    )
};

export default Loader;