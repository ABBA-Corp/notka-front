function About() {
    return (
        <div className="About parent">ABOUT PAGE</div>
    )
};

export default About;