export const BASE_URL = `https://swift.abba.uz/api`;

export const NEWS_DATA_URL = `${BASE_URL}/headerslider`;
export const LENTA_DATA_URL = `${BASE_URL}/headerslider`;
export const GALLERY_DATA_URL = `${BASE_URL}/headerslider`;
export const PRODUCTS_DATA_URL = `${BASE_URL}/headerslider`;
export const CATEGORIES_DATA_URL = `${BASE_URL}/headerslider`;